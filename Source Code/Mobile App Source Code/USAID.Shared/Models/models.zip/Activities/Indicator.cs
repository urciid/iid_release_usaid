﻿using System;
using System.Collections.Generic;
using SQLite.Net.Attributes;
using WMP.Core.Data.SQLiteNet;

namespace USAID.Models
{
	public class Indicator : IModel
	{
		[PrimaryKey, AutoIncrement]
		public int Id { get; set; }
		public DateTime Created { get; set; }
		public DateTime Modified { get; set; }

		public string IndicatorId { get; set; }
		public string IndicatorType { get; set; }

		public string Name { get; set; }
		public string Type { get; set; }

		public string Sex { get; set;}
		public string Definition { get; set;}
		public string Aim { get; set;}
		public string Frequency { get; set;}
		public string NumeratorName { get; set;}
		public string NumeratorDefinition { get; set;}
		public string DenominatorName { get; set; }
		public string DenominatorDefinition { get; set; }

		public List<Period> Periods { get; set; }
		public List<Age> Age { get; set; }
		public Activity Activity { get; set; }
		public List<Change> Changes { get; set; }
		public List<Attachment> Attachments { get; set;}
		public List<Comment> Comments { get; set;}

		public List<Observation> ObservationsTemplate { get; set;}
		public List<Observation> Observations { get; set;}



	}
}
