﻿using System;
using System.Collections.Generic;
using SQLite.Net.Attributes;
using WMP.Core.Data.SQLiteNet;

namespace USAID.Models
{
	public class Observation  : IModel
	{
		[PrimaryKey, AutoIncrement]
		public int Id { get; set; }
		public DateTime Created { get; set; }
		public DateTime Modified { get; set; }

		public int ObservationId { get; set;}
		public int Numerator { get; set; }
		public int Denominator { get; set;}
		public Period Period { get; set; }

	}
}
