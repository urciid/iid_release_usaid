﻿using System;
using System.Collections.Generic;
using SQLite.Net.Attributes;
using WMP.Core.Data.SQLiteNet;

namespace USAID.Models
{
	public class Attachment : IModel
	{
		[PrimaryKey, AutoIncrement]
		public int Id { get; set; }
		public DateTime Created { get; set; }
		public DateTime Modified { get; set; }

		public int AttachmentId { get; set; }
		public int ObservationId { get; set; }
		public string FileName { get; set; }
		//public System. StartDate { get; set; } //need file type
	}
}
